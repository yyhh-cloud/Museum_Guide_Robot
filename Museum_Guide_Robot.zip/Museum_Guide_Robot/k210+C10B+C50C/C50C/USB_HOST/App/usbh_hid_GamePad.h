#ifndef __USBH_HID_GAMEPAD_H
#define __USBH_HID_GAMEPAD_H


#endif /* __USBH_HID_GAMEPAD_H */
